import {json,options,ensureSchema,dbOrError} from './_shared.js';
export async function onRequestGet({env}){try{const db=dbOrError(env);await ensureSchema(db);const r=await db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name IN ('saad_products','saad_product_images','saad_inquiries') ORDER BY name").all();return json({ok:true,d1:true,tables:r.results.map(x=>x.name),message:'SAAD Engineering API + D1 connected'});}catch(e){return json({ok:false,error:String(e?.message||e)},500)}}
export async function onRequestOptions(){return options()}
