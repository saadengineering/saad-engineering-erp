const CORS={
  'Access-Control-Allow-Origin':'*',
  'Access-Control-Allow-Methods':'GET,POST,PUT,DELETE,OPTIONS',
  'Access-Control-Allow-Headers':'Content-Type'
};
export function json(data,status=200){
  return new Response(JSON.stringify(data),{status,headers:{...CORS,'Content-Type':'application/json'}});
}
export function options(){ return new Response(null,{status:204,headers:CORS}); }
export async function ensureSchema(db){
  await db.prepare(`CREATE TABLE IF NOT EXISTS saad_products (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,cat TEXT DEFAULT '',description TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP)`).run();
  await db.prepare(`CREATE TABLE IF NOT EXISTS saad_product_images (id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,public_url TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)`).run();
  await db.prepare(`CREATE TABLE IF NOT EXISTS saad_inquiries (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT NOT NULL,email TEXT DEFAULT '',product TEXT DEFAULT '',message TEXT NOT NULL,status TEXT DEFAULT 'New',created_at TEXT DEFAULT CURRENT_TIMESTAMP)`).run();
  const ensureColumn=async(table,column,definition)=>{const info=await db.prepare(`PRAGMA table_info(${table})`).all();if(!info.results.some(x=>x.name===column))await db.prepare(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`).run();};
  await ensureColumn('saad_products','cat',"TEXT DEFAULT ''");
  await ensureColumn('saad_products','description',"TEXT DEFAULT ''");
  await ensureColumn('saad_products','created_at',"TEXT DEFAULT CURRENT_TIMESTAMP");
  await ensureColumn('saad_product_images','product_id','INTEGER');
  await ensureColumn('saad_product_images','public_url','TEXT');
  await ensureColumn('saad_product_images','created_at',"TEXT DEFAULT CURRENT_TIMESTAMP");
  await ensureColumn('saad_inquiries','email',"TEXT DEFAULT ''");
  await ensureColumn('saad_inquiries','product',"TEXT DEFAULT ''");
  await ensureColumn('saad_inquiries','status',"TEXT DEFAULT 'New'");
  await ensureColumn('saad_inquiries','created_at',"TEXT DEFAULT CURRENT_TIMESTAMP");
}
export function dbOrError(env){if(!env?.DB)throw new Error('D1 binding DB is missing. Cloudflare Pages Settings > Bindings: Name DB, Database saadengineering.');return env.DB;}
export async function saveProduct(request,env,id=null){
  const db=dbOrError(env); await ensureSchema(db);
  let b; try{b=await request.json()}catch(e){return json({ok:false,error:'Invalid JSON body'},400)}
  const name=String(b?.name||'').trim(); if(!name)return json({ok:false,error:'Product name is required'},400);
  const cat=String(b?.cat||''); const desc=String(b?.desc||b?.description||'');
  if(id!==null){
    await db.prepare('UPDATE saad_products SET name=?,cat=?,description=? WHERE id=?').bind(name,cat,desc,id).run();
    await db.prepare('DELETE FROM saad_product_images WHERE product_id=?').bind(id).run();
  }else{
    const r=await db.prepare('INSERT INTO saad_products(name,cat,description) VALUES(?,?,?)').bind(name,cat,desc).run();
    id=r.meta.last_row_id;
  }
  const images=Array.isArray(b?.images)?b.images:[];
  for(const u of images){if(typeof u==='string' && /^https:\/\/res\.cloudinary\.com\//.test(u))await db.prepare('INSERT INTO saad_product_images(product_id,public_url) VALUES(?,?)').bind(id,u).run();}
  return json({ok:true,id},200);
}
