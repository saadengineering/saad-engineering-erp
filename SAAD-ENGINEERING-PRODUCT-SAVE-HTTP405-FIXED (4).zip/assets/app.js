const API="/api";
let cacheProducts=[];
async function products(){const r=await fetch(API+"/products"); if(!r.ok) throw new Error("Products API failed"); cacheProducts=await r.json(); return cacheProducts}
async function renderProducts(){
 const q=(document.getElementById("search")?.value||"").toLowerCase();
 try{
  const all=await products();
  const ps=all.filter(p=>(p.name+" "+(p.cat||"")+" "+(p.desc||"")).toLowerCase().includes(q));
  document.getElementById("productGrid").innerHTML=ps.map(p=>{
   const img=p.images?.[0]||"";
   return `<article class="product-card">${img?`<img src="${img}">`:`<div class="product-placeholder">⚙</div>`}<div class="pc-body"><small>${esc(p.cat||"Engineering")}</small><h3>${esc(p.name)}</h3><p>${esc(p.desc)}</p><a class="wa small" target="_blank" href="${wa(p.name)}">WhatsApp Inquiry</a></div></article>`
  }).join("")||"<p>No products found.</p>";
  renderGallery(all);
 }catch(e){document.getElementById("productGrid").innerHTML="<p>Unable to load products. Please check the Cloudflare bindings.</p>"}
}
function renderGallery(ps){document.getElementById("galleryGrid").innerHTML=ps.flatMap(p=>(p.images||[]).map(img=>`<div class="gallery-item"><img src="${img}"><span>${esc(p.name)}</span></div>`)).join("")||`<div class="empty-gallery">Product pictures uploaded by Admin will appear here.</div>`}
function wa(name){return "https://wa.me/8801628915220?text="+encodeURIComponent("Hello SAAD Engineering, I am interested in "+name+". Please share price, specification and availability.")}
document.getElementById("inquiryForm").addEventListener("submit",async e=>{e.preventDefault();let f=new FormData(e.target);let payload={name:f.get("name"),phone:f.get("phone"),email:f.get("email")||"",message:f.get("message"),product:"General Inquiry"};try{let r=await fetch(API+"/inquiries",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});if(!r.ok)throw 0;alert("Inquiry submitted successfully.");let msg=`Hello SAAD Engineering,\nName: ${payload.name}\nPhone: ${payload.phone}\nEmail: ${payload.email}\nInquiry: ${payload.message}`;window.open("https://wa.me/8801628915220?text="+encodeURIComponent(msg),"_blank");e.target.reset()}catch(_){alert("Inquiry could not be submitted. Please try WhatsApp.")}});
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
renderProducts();
let currentSlide=0,slideTimer;
function initHeroSlider(){const slides=[...document.querySelectorAll(".slide")],dots=document.getElementById("slideDots");if(!slides.length)return;dots.innerHTML=slides.map((_,i)=>`<span class="slider-dot ${i===0?"active":""}" onclick="goSlide(${i})"></span>`).join("");window.goSlide=i=>{currentSlide=(i+slides.length)%slides.length;slides.forEach((x,n)=>x.classList.toggle("active",n===currentSlide));[...dots.children].forEach((x,n)=>x.classList.toggle("active",n===currentSlide))};window.nextSlide=()=>goSlide(currentSlide+1);window.prevSlide=()=>goSlide(currentSlide-1);slideTimer=setInterval(nextSlide,4500)}
initHeroSlider();
