SAAD ENGINEERING V2
====================
Customer website: /
Admin panel: /admin/

Admin login:
ID: admin
Password: saad123

This version keeps the customer-facing website and Admin UI separate.
Admin product pictures are stored as browser data in localStorage for this starter build,
and customer inquiries are also stored locally. For multi-device production deployment
on Cloudflare, connect the same UI to Cloudflare D1 + R2 (or another shared backend).
Do not use the demo credentials in a production environment.
